import { Slot, Tabs } from "expo-router";
import { useColorScheme } from "react-native";
import { ThemeProvider, useTheme } from "../theme/ThemeProvider";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

export default function Layout() {
  const scheme = useColorScheme();
  return (
    <ThemeProvider scheme={scheme ?? "dark"}>
      <ThemedTabs />
    </ThemeProvider>
  );
}

function ThemedTabs() {
  const { colors, scheme } = useTheme();
  const activeBlue = "#1E3A8A";
  const inactiveGray = "#6B7280";
  const barBackground = scheme === "light" ? "#FFFFFF" : colors.background;
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: activeBlue,
        tabBarInactiveTintColor: inactiveGray,
        tabBarStyle: {
          backgroundColor: barBackground,
          borderTopColor: colors.border,
          shadowColor: "#000",
          shadowOpacity: 0.06,
          shadowRadius: 8,
          shadowOffset: { width: 0, height: -2 },
          elevation: 8,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Dashboard",
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="dashboard" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="world"
        options={{
          title: "World Clock",
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="public" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="alarms"
        options={{
          title: "Attendance",
          // Gold accent when active
          tabBarActiveTintColor: "#FACC15",
          tabBarIcon: ({ color, size, focused }) => (
            <MaterialIcons name="schedule" size={size} color={focused ? "#FACC15" : color} />
          ),
        }}
      />
      <Tabs.Screen
        name="stopwatch"
        options={{
          title: "Stopwatch",
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="timer" size={size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}

