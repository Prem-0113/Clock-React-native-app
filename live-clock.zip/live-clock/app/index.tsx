import { Text, View, Image, Pressable } from "react-native";
import { useEffect, useMemo, useState } from "react";
import { useTheme } from "../theme/ThemeProvider";

const TIME_OVERRIDE: { hour: number; minute: number; second?: number } | null = null;
const DIGITAL_USE_24H = false;
const DIGITAL_SHOW_SECONDS = true;

function LiveClock() {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => {
      const current = new Date();
      if (TIME_OVERRIDE) {
        const d = new Date(current);
        d.setHours(TIME_OVERRIDE.hour);
        d.setMinutes(TIME_OVERRIDE.minute);
        d.setSeconds(TIME_OVERRIDE.second ?? 0);
        setNow(d);
      } else {
        setNow(current);
      }
    }, 1000);
    return () => clearInterval(id);
  }, []);

  const timeString = now.toLocaleTimeString();
  const dateString = now.toLocaleDateString();

  return (
    <View style={{ alignItems: "center" }}>
      <Text style={{ fontSize: 48, fontWeight: "700" }}>{timeString}</Text>
      <Text style={{ fontSize: 18, opacity: 0.7 }}>{dateString}</Text>
    </View>
  );
}

export default function Index() {
  const { colors, toggleScheme, scheme } = useTheme();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <View
      style={{
        flex: 1,
        justifyContent: "flex-start",
        alignItems: "center",
        backgroundColor: colors.background,
        paddingTop: 10,
      }}
    >
      <View style={{ width: "90%", alignItems: "flex-end",height: 60 }}>
        <Pressable onPress={toggleScheme} style={{ padding: 8, marginRight: 9, marginTop: 2, backgroundColor: "#0f172a", borderRadius: 9999 }}>
          <Text style={{ color: colors.primary, fontWeight: "800" }}>{scheme === "dark" ? "☀︎" : "☾"}</Text>
        </Pressable>
      </View>
      <Image
        source={require("../assets/images/tech.png")}
        resizeMode="contain"
        style={{ width: "102%", height: 150, marginBottom: 12, borderRadius: 15 }}
      />
      <View style={{ alignItems: "center", marginBottom: 8 }}>
        <Text style={{ color: colors.text, fontSize: 22, fontWeight: "900" }}>Sevael Technologies</Text>
        <Text style={{ color: colors.muted, fontSize: 14, marginTop: 2, textAlign: "center" }}>
          Technology enablers for digital transformation • IT Services and IT Consulting & Industry 4.0
        </Text>
      </View>
      <DigitalReadout now={now} />
    </View>
  );
}

// Removed analog clock; showing only digital readout

function DigitalReadout({ now }: { now: Date }) {
  const { colors } = useTheme();
  const text = useMemo(() => {
    const time = new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: DIGITAL_SHOW_SECONDS ? "2-digit" : undefined,
      hour12: !DIGITAL_USE_24H,
    }).format(now);
    const date = new Intl.DateTimeFormat("en-US", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "2-digit",
    }).format(now);
    return { time, date };
  }, [now]);

  return (
    <View style={{ alignItems: "center", marginTop: 16 }}>
      <Text style={{ fontSize: 44, fontWeight: "800", color: colors.primary, textShadowColor: colors.primaryGlow, textShadowRadius: 12 }}>
        {text.time}
      </Text>
      <Text style={{ fontSize: 16, color: colors.muted, marginTop: 6 }}>{text.date}</Text>
    </View>
  );
}

// No time zone conversion needed for digital-only mode
