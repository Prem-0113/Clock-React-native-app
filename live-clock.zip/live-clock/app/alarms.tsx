import { View, Text, TextInput, Pressable, Image, Platform, Alert } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
// Optional native PDF sharing (web uses new window). If unavailable, we fallback.
let Print: any = null;
let Sharing: any = null;
try { Print = require("expo-print"); } catch {}
try { Sharing = require("expo-sharing"); } catch {}
import { useState, useMemo, useEffect } from "react";
import { useTheme } from "../theme/ThemeProvider";

type DayRecord = {
  employeeId: string;
  dateKey: string;
  inTime?: Date;
  lunchStart?: Date;
  lunchEnd?: Date;
  outTime?: Date;
};

export default function Attendance() {
  const { colors } = useTheme();
  const [employeeId, setEmployeeId] = useState("");
  const [record, setRecord] = useState<DayRecord | null>(null);
  const [now, setNow] = useState(new Date());
  const [verified, setVerified] = useState(false);
  useEffect(() => { const id = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(id); }, []);

  const dateKey = useMemo(() => new Date().toISOString().slice(0, 10), [now]);

  function setField<K extends keyof DayRecord>(key: K, value: DayRecord[K]) {
    setRecord((prev) => {
      const base: DayRecord = prev ?? { employeeId, dateKey };
      const next = { ...base, [key]: value, employeeId, dateKey } as DayRecord;
      persistRecord(next);
      return next;
    });
  }

  const lunchMinutes = useMemo(() => diffMinutes(record?.lunchStart, record?.lunchEnd), [record]);
  const grossMinutes = useMemo(() => diffMinutes(record?.inTime, record?.outTime), [record]);
  const allSet = !!(record?.inTime && record?.outTime && record?.lunchStart && record?.lunchEnd);
  const workMinutes = allSet ? Math.max(0, grossMinutes - lunchMinutes) : 0;

  const hasIn = !!record?.inTime;
  const hasLunchStart = !!record?.lunchStart;
  const hasLunchEnd = !!record?.lunchEnd;
  const hasOut = !!record?.outTime;

  return (
    <View style={{ flex: 1, padding: 16, backgroundColor: colors.background, paddingTop: 16 }}>
      <Image
        source={require("../assets/images/tech.png")}
        resizeMode="contain"
        style={{ width: "102%", height: 150, marginBottom: 5, borderRadius: 15 }}
      />
      <View style={{ alignItems: "center", marginBottom: 12 }}>
        <Text style={{ color: colors.text, fontSize: 22, fontWeight: "900" }}>Sevael Technologies</Text>
        <Text style={{ color: colors.muted, fontSize: 14, marginTop: 2, textAlign: "center" }}>
          Technology enablers for digital transformation • IT Services and IT Consulting & Industry 4.0
        </Text>
      </View>
      <Text style={{ color: colors.text, marginBottom: 8, fontWeight: "700" }}>Employee ID</Text>
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        <TextInput
          value={employeeId}
          onChangeText={(t) => { setEmployeeId(t); setVerified(false); setRecord(null); }}
          placeholder="Sevael Emp ID:"
          placeholderTextColor={colors.muted}
          style={{ flex: 1, backgroundColor: colors.card, color: colors.text, borderRadius: 12, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 12, paddingVertical: 10 }}
        />
        <Pressable
          onPress={() => {
            if (!employeeId.trim()) { Alert.alert("Enter ID", "Please enter Employee ID to verify."); return; }
            setVerified(true);
          }}
          style={{ marginLeft: 8, padding: 10, borderRadius: 9999, backgroundColor: verified ? "#16a34a" : colors.card, borderWidth: 1, borderColor: verified ? "#16a34a" : colors.border }}
        >
          <MaterialIcons name={verified ? "check" : "verified"} size={20} color={verified ? "#ffffff" : colors.muted} />
        </Pressable>
      </View>

      <View style={{ flexDirection: "row", flexWrap: "wrap", marginTop: 16 }}>
        <Btn label="Check-In" onPress={() => setField("inTime", new Date())} disabled={!verified || hasIn} />
        <Btn label="Lunch Start" onPress={() => setField("lunchStart", new Date())} disabled={!verified || !hasIn || hasLunchStart} />
        <Btn label="Lunch End" onPress={() => setField("lunchEnd", new Date())} disabled={!verified || !hasLunchStart || hasLunchEnd} />
        <Btn label="Check-Out" onPress={() => setField("outTime", new Date())} disabled={!verified || !hasIn || hasOut} />
        <Btn label="Reset Day" onPress={() => setRecord(null)} />
      </View>

      <View style={{ marginTop: 24, gap: 10 }}>
        <Row label="Date" value={dateKey} />
        <Row label="In Time" value={fmt(record?.inTime)} />
        <Row label="Lunch Start" value={fmt(record?.lunchStart)} />
        <Row label="Lunch End" value={fmt(record?.lunchEnd)} />
        <Row label="Out Time" value={fmt(record?.outTime)} />
        <Row label="Total Working" value={allSet ? minsToText(workMinutes) : undefined} emphasis />
      </View>

      {/* Export single-day PDF (today) */}
      <View style={{ marginTop: 28, alignItems: "center" }}>
        <Btn label="Export PDF" onPress={() => exportTodayPDF(employeeId, dateKey, record)} />
      </View>
    </View>
  );
}

function Btn({ label, onPress, disabled }: { label: string; onPress: () => void; disabled?: boolean }) {
  return (
    <Pressable onPress={onPress} disabled={disabled} style={{ paddingHorizontal: 12, paddingVertical: 10, backgroundColor: disabled ? "#0f172a" : "#0b1220", opacity: disabled ? 0.5 : 1, borderRadius: 12, marginRight: 8, marginBottom: 8 }}>
      <Text style={{ color: "#9ff6ff", fontWeight: "700" }}>{label}</Text>
    </Pressable>
  );
}

function Row({ label, value, emphasis }: { label: string; value?: string; emphasis?: boolean }) {
  const { colors, scheme } = useTheme();
  const valueColor = scheme === "light" ? "#1E3A8A" : "#e5e7eb";
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
      <Text style={{ color: colors.muted, fontWeight: emphasis ? "800" : "400" }}>{label}</Text>
      <Text style={{ color: emphasis ? colors.primary : valueColor, fontWeight: emphasis ? "900" : "700" }}>{value ?? "—"}</Text>
    </View>
  );
}

function fmt(d?: Date) {
  if (!d) return undefined;
  return new Intl.DateTimeFormat("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true }).format(d);
}

function diffMinutes(a?: Date, b?: Date) {
  if (!a || !b) return 0;
  return Math.max(0, Math.round((b.getTime() - a.getTime()) / 60000));
}

function diffMinutesDynamic(a?: Date, b?: Date, now?: Date) {
  if (!a) return 0;
  const end = b ?? now;
  if (!end) return 0;
  return Math.max(0, Math.round((end.getTime() - a.getTime()) / 60000));
}

function minsToText(mins: number) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}h ${m}m`;
}

// --- Persistence + Export (web-first) ---
type Store = { records: DayRecord[] };
const STORAGE_KEY = "attendance_store_v1";

function getStore(): Store {
  try {
    const s = (globalThis as any).localStorage?.getItem(STORAGE_KEY);
    if (s) return JSON.parse(s) as Store;
  } catch {}
  return { records: [] };
}

function setStore(store: Store) {
  try {
    (globalThis as any).localStorage?.setItem(STORAGE_KEY, JSON.stringify(store));
  } catch {}
}

function persistRecord(rec: DayRecord) {
  const store = getStore();
  const k = `${rec.employeeId}__${rec.dateKey}`;
  const idx = store.records.findIndex((r) => `${r.employeeId}__${r.dateKey}` === k);
  if (idx >= 0) store.records[idx] = rec; else store.records.push(rec);
  setStore(store);
}

function filterByDateRange(records: DayRecord[], from?: string, to?: string) {
  const f = from ? new Date(from + "T00:00:00") : null;
  const t = to ? new Date(to + "T23:59:59") : null;
  return records.filter((r) => {
    const d = new Date(r.dateKey + "T12:00:00");
    if (f && d < f) return false;
    if (t && d > t) return false;
    return true;
  });
}

function handleExport(kind: "pdf", employeeId: string, from?: string, to?: string) {
  const store = getStore();
  const filtered = filterByDateRange(store.records.filter(r => !employeeId || r.employeeId === employeeId), from, to);
  if (filtered.length === 0) {
    Alert.alert("No data", "No attendance records in that range.");
    return;
  }
  const html = makeHtmlTable(filtered);
  if (typeof window !== "undefined") {
    const win = window.open("", "_blank");
    if (win) { win.document.write(html); win.document.close(); win.focus(); }
  } else {
    Alert.alert("PDF Export", "PDF export is available on web; on native we can integrate expo-print later.");
  }
}

function makeHtmlTable(rows: DayRecord[]) {
  const tr = (vals: string[]) => `<tr>${vals.map(v => `<td style="padding:6px 10px;border:1px solid #e5e7eb;">${v}</td>`).join("")}</tr>`;
  const header = tr(["Employee ID","Date","In","Lunch Start","Lunch End","Out","Total Hours"]);
  const body = rows.map(r => tr([
    r.employeeId,
    formatDateShort(r.dateKey),
    fmt(r.inTime) ?? "",
    fmt(r.lunchStart) ?? "",
    fmt(r.lunchEnd) ?? "",
    fmt(r.outTime) ?? "",
    minsToText(totalMinutes(r)),
  ])).join("");
  return `<!doctype html><html><head><meta charset="utf-8"><title>Attendance</title></head><body><h2>Attendance</h2><table style="border-collapse:collapse;border:1px solid #e5e7eb;">${header}${body}</table><script>window.print&&window.print();</script></body></html>`;
}

async function exportTodayPDF(employeeId: string, dateKey: string, rec: DayRecord | null) {
  if (!employeeId.trim()) { Alert.alert("Enter ID", "Please enter Employee ID and verify."); return; }
  if (!rec?.inTime || !rec?.lunchStart || !rec?.lunchEnd || !rec?.outTime) {
    Alert.alert("Missing times", "Fill In, Lunch Start, Lunch End, and Out before exporting.");
    return;
  }
  const row: DayRecord = { ...rec, employeeId, dateKey };
  persistRecord(row);
  const html = makeHtmlTable([row]);
  if (Platform.OS === "web") {
    const win = window.open("", "_blank");
    if (win) { win.document.write(html); win.document.close(); win.focus(); }
    return;
  }
  if (Print?.printToFileAsync) {
    try {
      const { uri } = await Print.printToFileAsync({ html, base64: false });
      if (Sharing?.isAvailableAsync && (await Sharing.isAvailableAsync())) {
        await Sharing.shareAsync(uri, { mimeType: "application/pdf", dialogTitle: "Share attendance PDF" });
      } else {
        Alert.alert("PDF ready", uri);
      }
      return;
    } catch (e: any) {
      Alert.alert("Export error", String(e?.message ?? e));
    }
  }
  Alert.alert("PDF Export", "PDF export is available on web. For native export, install expo-print & expo-sharing.");
}

function totalMinutes(r: DayRecord) {
  return Math.max(0, diffMinutes(r.inTime, r.outTime) - diffMinutes(r.lunchStart, r.lunchEnd));
}

function formatDateShort(dateKey: string) {
  const d = new Date(dateKey + "T12:00:00");
  const day = d.getDate().toString().padStart(2, "0");
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]; 
  const month = months[d.getMonth()];
  const year = d.getFullYear().toString().slice(2);
  return `${day}-${month}-${year}`;
}

