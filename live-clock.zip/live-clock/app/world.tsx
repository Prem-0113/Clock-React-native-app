import { View, Text, FlatList, TextInput, Pressable, Image } from "react-native";
import { useEffect, useMemo, useState } from "react";
import { useTheme } from "../theme/ThemeProvider";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

type Zone = { id: string; label: string; timeZone: string };

const PRESETS: Zone[] = [
  { id: "local", label: "Local", timeZone: "local" },
  { id: "Asia/Kolkata", label: "Kolkata", timeZone: "Asia/Kolkata" },
  { id: "Europe/London", label: "London", timeZone: "Europe/London" },
  { id: "America/New_York", label: "New York", timeZone: "America/New_York" },
  { id: "Asia/Tokyo", label: "Tokyo", timeZone: "Asia/Tokyo" },
  { id: "Australia/Sydney", label: "Sydney", timeZone: "Australia/Sydney" },
];

export default function World() {
  const { colors } = useTheme();
  const [now, setNow] = useState(new Date());
  const [zones, setZones] = useState<Zone[]>([PRESETS[0], PRESETS[1], PRESETS[2]]);
  const [input, setInput] = useState("");

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  function addZone(zone: Zone) {
    setZones((list) => (list.find((z) => z.id === zone.id) ? list : [...list, zone]));
  }

  function removeZone(id: string) {
    setZones((list) => list.filter((z) => z.id !== id));
  }

  function tryAddFromInput() {
    const tz = input.trim();
    if (!tz) return;
    try {
      // Validate by formatting once
      new Intl.DateTimeFormat("en-US", { timeZone: tz }).format(now);
      addZone({ id: tz, label: tz.split("/").pop() ?? tz, timeZone: tz });
      setInput("");
    } catch {
      // invalid tz; noop for now
    }
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Image
        source={require("../assets/images/tech.png")}
        resizeMode="contain"
        style={{ width: "102%", height: 150, marginBottom: 12, borderRadius: 15 }}
      />
      <View style={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 8 }}>
        <Text style={{ color: colors.text, marginBottom: 8, fontWeight: "700" }}>Quick add</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
          {PRESETS.slice(1).map((z) => (
            <Pressable
              key={z.id}
              onPress={() => addZone(z)}
              style={{ paddingHorizontal: 12, paddingVertical: 8, backgroundColor: "#0f172a", borderRadius: 16, marginRight: 8, marginBottom: 8 }}
            >
              <Text style={{ color: "#9ff6ff", fontWeight: "700" }}>{z.label}</Text>
            </Pressable>
          ))}
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", marginTop: 4 }}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Enter IANA time zone e.g. Europe/Paris"
            placeholderTextColor={colors.muted}
            style={{ flex: 1, paddingVertical: 10, paddingHorizontal: 12, borderRadius: 12, backgroundColor: colors.card, color: colors.text, borderWidth: 1, borderColor: colors.border }}
          />
          <Pressable onPress={tryAddFromInput} style={{ marginLeft: 8 }}>
            <MaterialIcons name="add-circle" size={28} color="#9ff6ff" />
          </Pressable>
        </View>
      </View>

      <FlatList
        data={zones}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 16 }}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        renderItem={({ item }) => <ZoneRow zone={item} now={now} onRemove={removeZone} />}
      />
    </View>
  );
}

function ZoneRow({ zone, now, onRemove }: { zone: Zone; now: Date; onRemove: (id: string) => void }) {
  const { colors } = useTheme();
  const formatted = useMemo(() => formatForZone(now, zone.timeZone), [now, zone.timeZone]);
  return (
    <View style={{ flexDirection: "row", alignItems: "center", backgroundColor: colors.surface, padding: 14, borderRadius: 14, borderWidth: 1, borderColor: colors.border }}>
      <View style={{ flex: 1 }}>
        <Text style={{ color: colors.primary, fontSize: 16, fontWeight: "700" }}>{zone.label}</Text>
        <Text style={{ color: colors.muted, marginTop: 2 }}>{formatted.date}</Text>
      </View>
      <Text style={{ color: colors.primary, fontSize: 20, fontWeight: "800", marginRight: 8 }}>{formatted.time}</Text>
      {zone.id !== "local" && (
        <Pressable onPress={() => onRemove(zone.id)}>
          <MaterialIcons name="delete" size={22} color="#94a3b8" />
        </Pressable>
      )}
    </View>
  );
}

function formatForZone(date: Date, timeZone: string) {
  const tz = timeZone === "local" ? undefined : timeZone;
  const time = new Intl.DateTimeFormat("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true, timeZone: tz }).format(date);
  const dateText = new Intl.DateTimeFormat("en-US", { weekday: "short", month: "short", day: "2-digit", timeZone: tz }).format(date);
  return { time, date: dateText };
}

