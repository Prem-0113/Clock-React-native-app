import { View, Text, Pressable, Image } from "react-native";
import { useEffect, useRef, useState } from "react";
import { useTheme } from "../theme/ThemeProvider";

export default function Stopwatch() {
  const { colors } = useTheme();
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const startRef = useRef<number | null>(null);
  useEffect(() => {
    let id: any;
    if (running) {
      const base = Date.now() - elapsed;
      id = setInterval(() => setElapsed(Date.now() - base), 16);
    }
    return () => id && clearInterval(id);
  }, [running]);

  const mm = Math.floor(elapsed / 60000).toString().padStart(2, "0");
  const ss = Math.floor((elapsed % 60000) / 1000).toString().padStart(2, "0");
  const ms = Math.floor((elapsed % 1000) / 10).toString().padStart(2, "0");

  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "flex-start", backgroundColor: colors.background, paddingTop: 16 }}>
      <Image
        source={require("../assets/images/tech.png")}
        resizeMode="contain"
        style={{ width: "102%", height: 150, marginBottom: 12, borderRadius: 15 }}
      />
      <View style={{ alignItems: "center", marginBottom: 8 }}>
        <Text style={{ color: colors.primary, fontSize: 22, fontWeight: "900" }}>Sevael Technologies</Text>
        <Text style={{ color: colors.muted, fontSize: 14, marginTop: 2, textAlign: "center" }}>
          Technology enablers for digital transformation • IT Services and IT Consulting & Industry 4.0
        </Text>
      </View>
      <Text style={{ fontSize: 48, color: colors.primary }}>{`${mm}:${ss}.${ms}`}</Text>
      <View style={{ flexDirection: "row", marginTop: 16 }}>
        <Button label={running ? "Stop" : "Start"} onPress={() => setRunning((v) => !v)} />
        <Button label="Reset" onPress={() => { setRunning(false); setElapsed(0); }} />
      </View>
    </View>
  );
}

function Button({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{ paddingHorizontal: 16, paddingVertical: 10, backgroundColor: "#0f172a", borderRadius: 16, marginHorizontal: 8 }}>
      <Text style={{ color: "#9ff6ff", fontWeight: "700" }}>{label}</Text>
    </Pressable>
  );
}

