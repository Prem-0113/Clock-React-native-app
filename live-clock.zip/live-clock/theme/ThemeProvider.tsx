import React, { createContext, useContext, useMemo, useState } from "react";
import { useColorScheme } from "react-native";

type Scheme = "light" | "dark";

type Theme = {
  scheme: Scheme;
  colors: {
    background: string;
    surface: string;
    card: string;
    primary: string;
    primaryGlow: string;
    muted: string;
    text: string;
    border: string;
  };
  setScheme?: (s: Scheme) => void;
  toggleScheme?: () => void;
};

const Light: Theme["colors"] = {
  // Premium clean white similar to "Amazon white"
  background: "#ffffff",
  surface: "#ffffff",
  card: "#f7f7f7",
  primary: "#0ea5e9",
  primaryGlow: "#67e8f9",
  muted: "#6b7280",
  text: "#0f172a",
  border: "#e5e7eb",
};

const Dark: Theme["colors"] = {
  background: "#000000",
  surface: "#0b1220",
  card: "#0f172a",
  primary: "#9ff6ff",
  primaryGlow: "#7efcff",
  muted: "#9ca3af",
  text: "#e5e7eb",
  border: "#1f2937",
};

const ThemeContext = createContext<Theme>({ scheme: "light", colors: Light });

export function ThemeProvider({ children, scheme }: { children: React.ReactNode; scheme?: Scheme }) {
  const fallback = useColorScheme() ?? "light";
  const [manual, setManual] = useState<Scheme | null>(null);
  const active = manual ?? scheme ?? fallback;
  const value = useMemo<Theme>(
    () => ({
      scheme: active,
      colors: active === "dark" ? Dark : Light,
      setScheme: (s: Scheme) => setManual(s),
      toggleScheme: () => setManual((prev) => (prev ?? active) === "dark" ? "light" : "dark"),
    }),
    [active]
  );
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  return useContext(ThemeContext);
}

